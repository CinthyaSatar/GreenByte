from flask import render_template, flash, redirect, url_for
from greenbyte import app, db, bcrypt
from greenbyte.forms import RegistrationForm, LoginForm
from greenbyte.models import User, Task
from flask_login import login_user, current_user, logout_user


activities = [
    {
        "Person": "Jake Jewell",
        "Green": "Lettuce",
        "Task": "Seed planting",
        "Quantity": 20,
        "Location": "B4",
        "Date": "2011/07/25"
    },{
        "Person": "Jake Jewell",
        "Green": "Lettuce",
        "Task": "Seed planting",
        "Quantity": 20,
        "Location": "B4",
        "Date": "2011/07/25"
    },{
        "Person": "Jake Jewell",
        "Green": "Lettuce",
        "Task": "Seed planting",
        "Quantity": 20,
        "Location": "B4",
        "Date": "2011/07/25"
    },{
        "Person": "Jake Jewell",
        "Green": "Lettuce",
        "Task": "Seed planting",
        "Quantity": 20,
        "Location": "B4",
        "Date": "2011/07/25"
    },{
        "Person": "Jake Jewell",
        "Green": "Lettuce",
        "Task": "Seed planting",
        "Quantity": 20,
        "Location": "B4",
        "Date": "2011/07/25"
    },{
        "Person": "Jake Jewell",
        "Green": "Lettuce",
        "Task": "Seed planting",
        "Quantity": 20,
        "Location": "B4",
        "Date": "2011/07/25"
    },{
        "Person": "Jake Jewell",
        "Green": "Lettuce",
        "Task": "Seed planting",
        "Quantity": 20,
        "Location": "B4",
        "Date": "2011/07/25"
    },{
        "Person": "Jake Jewell",
        "Green": "Lettuce",
        "Task": "Seed planting",
        "Quantity": 20,
        "Location": "B4",
        "Date": "2011/07/25"
    },{
        "Person": "Jake Jewell",
        "Green": "Lettuce",
        "Task": "Seed planting",
        "Quantity": 20,
        "Location": "B4",
        "Date": "2011/07/25"
    },{
        "Person": "Jake Jewell",
        "Green": "Lettuce",
        "Task": "Seed planting",
        "Quantity": 20,
        "Location": "B4",
        "Date": "2011/07/25"
    },

]

@app.route("/")
def index():
    return render_template('index.html', activities=activities)


@app.route("/register", methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = RegistrationForm()
    if form.validate_on_submit():

        hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user = User(firstName=form.firstName.data, lastName=form.lastName.data,email=form.email.data,password=hashed_password)
        db.session.add(user)
        db.session.commit()
        flash(f"Account created for {form.firstName.data}! You can now login.", "success")
        return redirect(url_for('login'))
    else:
        flash(f"Registration unsuccessful! try again", "danger")

    return render_template('register.html', title="Register", form=form)


@app.route("/login", methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and bcrypt.check_password_hash(user.password, form.password.data):
            login_user(user, remember=form.remember.data)
        
            flash(f"Welcome!", "success")
            return redirect(url_for('index'))
        else:
            flash(f"Login Unsuccessful! try again", "danger")

    return render_template('login.html', title="Login", form=form)



@app.route("/logout")
def logout():
    logout_user()

@app.route("/aboutMe")
def aboutMe():
    return render_template('aboutMe.html', title="About Me")

@app.route("/hydroPlanting")
def hydroPlanting():
    return render_template('hydroPlanting.html', title="Hydro Planting")

@app.route("/seedPlanting")
def seedPlanting():
    return render_template('seedPlanting.html', title="Seed Planting")

@app.route("/myTime")
def myTime():
    return render_template('myTime.html', title="My Time")

